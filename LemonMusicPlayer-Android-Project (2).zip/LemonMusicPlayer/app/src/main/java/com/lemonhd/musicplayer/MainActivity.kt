package com.lemonhd.musicplayer

import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

private data class Song(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private val songs = mutableListOf<Song>()
    private var visibleSongs = listOf<Song>()
    private var player: MediaPlayer? = null
    private var current = -1
    private var shuffle = false
    private var repeat = false
    private var activeTab = "Songs"
    private lateinit var songList: ListView
    private lateinit var songAdapter: SongAdapter
    private lateinit var search: EditText
    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var playButton: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeView: TextView
    private lateinit var countView: TextView
    private val requestCode = 41
    private val bg = Color.rgb(16, 17, 23)
    private val panel = Color.rgb(29, 31, 42)
    private val accent = Color.rgb(174, 151, 255)
    private val muted = Color.rgb(165, 166, 180)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (hasAudioPermission()) loadSongs() else requestAudioPermission()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(10))
            setBackgroundColor(bg)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        brand.addView(text("LEMON MUSIC", 22f, Color.WHITE, true))
        brand.addView(text("Your sound. Your library.", 12f, muted))
        top.addView(brand)
        val refresh = TextView(this).apply {
            text = "⟳"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(accent)
            setOnClickListener { loadSongs() }
        }
        top.addView(refresh, LinearLayout.LayoutParams(dp(44), dp(48)))
        root.addView(top)

        search = EditText(this).apply {
            hint = "Search songs, artists, albums"; setHintTextColor(muted); setTextColor(Color.WHITE)
            textSize = 14f; singleLine = true; setPadding(dp(15), 0, dp(15), 0)
            background = rounded(panel, 16)
        }
        val searchParams = LinearLayout.LayoutParams(-1, dp(48)); searchParams.topMargin = dp(20)
        root.addView(search, searchParams)

        lateinit var tabs: LinearLayout
        tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(8)) }
        listOf("Songs", "Albums", "Artists").forEach { tab ->
            val item = TextView(this).apply {
                text = tab; textSize = 14f; gravity = Gravity.CENTER
                setTextColor(if (tab == activeTab) accent else muted)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener { activeTab = tab; updateList(search.text.toString());
                    for (i in 0 until tabs.childCount) (tabs.getChildAt(i) as TextView).setTextColor(if ((tabs.getChildAt(i) as TextView).text == activeTab) accent else muted)
                }
            }
            tabs.addView(item, LinearLayout.LayoutParams(0, dp(42), 1f))
        }
        root.addView(tabs)

        val section = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(8)) }
        section.addView(text("MY LIBRARY", 11f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        countView = text("0 TRACKS", 10f, muted, true)
        section.addView(countView)
        root.addView(section)

        songList = ListView(this).apply {
            divider = null; selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            cacheColorHint = bg; setBackgroundColor(bg)
        }
        songAdapter = SongAdapter()
        songList.adapter = songAdapter
        songList.setOnItemClickListener { _, _, position, _ ->
            val song = visibleSongs[position]
            val index = songs.indexOf(song)
            if (index >= 0) playSong(index)
        }
        root.addView(songList, LinearLayout.LayoutParams(-1, 0, 1f))

        val now = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(13), dp(15), dp(12))
            background = rounded(panel, 20)
        }
        val nowRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val cover = TextView(this).apply {
            text = "♫"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = rounded(0xFF51447A.toInt(), 13)
        }
        nowRow.addView(cover, LinearLayout.LayoutParams(dp(48), dp(48)))
        val meta = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        titleView = text("Choose a song", 14f, Color.WHITE, true)
        artistView = text("Nothing playing", 12f, muted)
        meta.addView(titleView); meta.addView(artistView)
        nowRow.addView(meta)
        playButton = text("▶", 24f, accent, true).apply { gravity = Gravity.CENTER; setOnClickListener { togglePlay() } }
        nowRow.addView(playButton, LinearLayout.LayoutParams(dp(44), dp(48)))
        now.addView(nowRow)
        seek = SeekBar(this).apply { max = 1000; progress = 0; progressTintList = android.content.res.ColorStateList.valueOf(accent); thumbTintList = android.content.res.ColorStateList.valueOf(accent) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) player?.let { if (it.duration > 0) it.seekTo(it.duration * p / 1000) } }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        now.addView(seek, LinearLayout.LayoutParams(-1, dp(28)))
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        fun control(label: String, action: () -> Unit, wide: Int = 48): TextView = text(label, 19f, muted, true).apply {
            gravity = Gravity.CENTER; setOnClickListener { action() }; controls.addView(this, LinearLayout.LayoutParams(dp(wide), dp(40)))
        }
        control("⤨", { shuffle = !shuffle; toast(if (shuffle) "Shuffle on" else "Shuffle off") })
        control("|◀", { previous() })
        control("▶", { togglePlay() }, 54)
        control("▶|", { next() })
        control("↻", { repeat = !repeat; toast(if (repeat) "Repeat on" else "Repeat off") })
        now.addView(controls)
        root.addView(now, LinearLayout.LayoutParams(-1, -2))

        search.addTextChangedListener(SimpleWatcher { updateList(it) })
        setContentView(root)
    }

    private inner class SongAdapter : BaseAdapter() {
        override fun getCount() = visibleSongs.size
        override fun getItem(position: Int) = visibleSongs[position]
        override fun getItemId(position: Int) = visibleSongs[position].id
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val s = getItem(position)
            val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, dp(7)) }
            val art = TextView(this@MainActivity).apply {
                text = "♫"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(accent)
                background = rounded(if (position % 2 == 0) 0xFF302B43.toInt() else 0xFF26333A.toInt(), 12)
            }
            row.addView(art, LinearLayout.LayoutParams(dp(48), dp(48)))
            val details = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            details.addView(text(s.title, 14f, Color.WHITE, true))
            details.addView(text("${s.artist}  •  ${s.album}", 11f, muted))
            row.addView(details)
            row.addView(text("⋮", 22f, muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(28), dp(48)))
            return row
        }
    }

    private fun updateList(query: String = "") {
        val q = query.trim().lowercase()
        val base = when (activeTab) {
            "Albums" -> songs.distinctBy { it.album }.map { it.copy(title = it.album, artist = "Album • ${it.artist}") }
            "Artists" -> songs.distinctBy { it.artist }.map { it.copy(title = it.artist, artist = "Artist") }
            else -> songs
        }
        visibleSongs = base.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q) }
        songAdapter.notifyDataSetChanged()
        countView.text = "${visibleSongs.size} ${if (activeTab == "Songs") "TRACKS" else activeTab.uppercase()}"
    }

    private fun hasAudioPermission(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    }
    private fun requestAudioPermission() {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        ActivityCompat.requestPermissions(this, arrayOf(p), requestCode)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == this.requestCode && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) loadSongs()
        else toast("Allow music access to show your songs")
    }

    private fun loadSongs() {
        songs.clear()
        val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL) else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val cursor: Cursor? = contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")
        cursor?.use {
            val id = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val title = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artist = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val album = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            while (it.moveToNext()) {
                val songId = it.getLong(id)
                songs.add(Song(songId, it.getString(title) ?: "Unknown title", it.getString(artist) ?: "Unknown artist", it.getString(album) ?: "Unknown album", Uri.withAppendedPath(collection, songId.toString())))
            }
        }
        updateList(search.text.toString())
        if (songs.isEmpty()) toast("No music files found on your phone")
    }

    private fun playSong(index: Int) {
        if (songs.isEmpty()) return
        current = index.coerceIn(0, songs.lastIndex)
        player?.release()
        player = MediaPlayer().apply {
            setDataSource(this@MainActivity, songs[current].uri)
            setOnPreparedListener { mp -> mp.start(); playButton.text = "Ⅱ"; titleView.text = songs[current].title; artistView.text = songs[current].artist; seek.progress = 0; seek.max = 1000; updateProgress() }
            setOnCompletionListener { if (repeat) playSong(current) else next() }
            setOnErrorListener { _, _, _ -> toast("Unable to play this audio"); true }
            prepareAsync()
        }
    }
    private fun updateProgress() {
        val p = player ?: return
        if (p.isPlaying) {
            try { seek.progress = if (p.duration > 0) p.currentPosition * 1000 / p.duration else 0 } catch (_: Exception) {}
            seek.postDelayed({ updateProgress() }, 500)
        }
    }
    private fun togglePlay() {
        val p = player
        if (p == null) { if (songs.isNotEmpty()) playSong(if (current < 0) 0 else current); return }
        if (p.isPlaying) { p.pause(); playButton.text = "▶" } else { p.start(); playButton.text = "Ⅱ"; updateProgress() }
    }
    private fun next() {
        if (songs.isEmpty()) return
        val n = if (shuffle && songs.size > 1) songs.indices.filter { it != current }.random() else (current + 1) % songs.size
        playSong(n)
    }
    private fun previous() {
        if (songs.isEmpty()) return
        if (player != null && player!!.currentPosition > 3000) player?.seekTo(0) else playSong(if (current <= 0) songs.lastIndex else current - 1)
    }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}

private class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
