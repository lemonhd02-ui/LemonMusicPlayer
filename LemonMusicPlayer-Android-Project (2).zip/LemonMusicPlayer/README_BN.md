# Lemon Music Player

Samsung Music-এর মতো পরিচ্ছন্ন, ডার্ক-থিম Android অডিও প্লেয়ার UI। এতে ফোনের লোকাল অডিও লাইব্রেরি, Songs/Albums/Artists ট্যাব, সার্চ, প্লেব্যাক, seek, previous/next, shuffle এবং repeat রয়েছে। এটি Samsung-এর অফিসিয়াল অ্যাপ নয়।

## APK তৈরি (কম্পিউটারে)
1. Android Studio-তে এই প্রজেক্টটি খুলুন। JDK 17 এবং Android SDK Platform 35 ইনস্টল থাকতে হবে।
2. Gradle sync শেষ হলে **Build > Build Bundle(s) / APK(s) > Build APK(s)** চাপুন।
3. APK পাবেন `app/build/outputs/apk/debug/app-debug.apk` ফাইলে।

## GitHub Actions দিয়ে APK তৈরি
1. ZIP Extract করে সব ফাইল একটি নতুন GitHub repository-তে upload/push করুন।
2. GitHub repository-র **Actions** ট্যাবে যান।
3. **Build Android APK** workflow নির্বাচন করে **Run workflow** চাপুন (অথবা `main` branch-এ push করুন)।
4. Build শেষ হলে workflow run-এর নিচের **Artifacts** থেকে `Lemon-Music-Player-APK` ডাউনলোড করুন। ZIP-এর ভেতরের `app-debug.apk` ফোনে Install করুন।

প্রথমবার চালু করলে ফোনের অডিও ফাইল পড়ার অনুমতি দিতে হবে।
